import React from "react";

const features: string[] = [
  "Display: QLED 4K Ultra HD, 3840 x 2160 pixels, 60 Hz Refresh Rate",
  "Connectivity: 5 HDMI | 1 USB | Wi-Fi",
  "Operating System: Google",
  "Apps: Disney Plus Hotstar, Netflix, YouTube, Prime Video",
  "Sound: 35 W Speaker, Dolby Atmos",
  "USP: Support Video Chat through Google Meet, DTS Virtual:X, MEMC Algorithm",
];

const KeyFeatures: React.FC = () => {
  return (
    // <div className="text-white p-4 mt-4 rounded-lg border border-gray-700">
    //   <h3 className="text-lg font-semibold mb-2">Key Features</h3>
    //   <ul className="list-disc pl-5 space-y-1 text-sm text-gray-300">
    //     {features.map((feature, index) => (
    //       <li key={index}>{feature}</li>
    //     ))}
    //   </ul>
    // </div>
    <></>
  );
};

export default KeyFeatures;
