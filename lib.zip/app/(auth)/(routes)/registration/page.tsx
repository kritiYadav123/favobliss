import { RegistrationForm } from "@/components/auth/forms/registration-form";

const RegistrationPage = () => {
    return (
        <div>
            <RegistrationForm/>
        </div>
    )
}

export default RegistrationPage;