import { ForgetPasswordForm } from "@/components/auth/forms/forget-password-form";

const ForgetPasswordPage = () => {
    return (
        <div>
            <ForgetPasswordForm/>
        </div>
    )
}

export default ForgetPasswordPage;