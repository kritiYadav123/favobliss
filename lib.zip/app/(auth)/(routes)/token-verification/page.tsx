import { TokenVerificationForm } from "@/components/auth/forms/token-verification-form";

const TokenVerificationPage = () => {
    return (
        <div>
            <TokenVerificationForm/>
        </div>
    );
}

export default TokenVerificationPage;