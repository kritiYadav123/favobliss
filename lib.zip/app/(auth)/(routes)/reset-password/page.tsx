import { ResetPasswordForm } from "@/components/auth/forms/reset-password-form";

const ResetPasswordPage = () => {
    return (
        <div>
            <ResetPasswordForm/>
        </div>
    )
}

export default ResetPasswordPage;